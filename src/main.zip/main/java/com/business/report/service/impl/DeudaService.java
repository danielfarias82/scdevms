package com.business.report.service.impl;

import com.business.report.model.DeudaRequest;
import com.business.report.model.DeudaResponse;
import com.business.report.model.DestinoRequest;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class DeudaService {

    @Value("${experian.services.iurl_deuda}")
    private String deudaServiceUrl;

    @Value("${experian.services.destino}")
    private String destinoServiceUrl;

    private final RestTemplate proxyRestTemplate; // RestTemplate configurado con proxy
    private final RestTemplate defaultRestTemplate; // RestTemplate sin proxy
    private final TokenServiceImpl tokenService;

    // Inyectar ambos RestTemplates
    public DeudaService(
            @Qualifier("proxyRestTemplate") RestTemplate proxyRestTemplate,
            @Qualifier("defaultRestTemplate") RestTemplate defaultRestTemplate,
            TokenServiceImpl tokenService) {
        this.proxyRestTemplate = proxyRestTemplate;
        this.defaultRestTemplate = defaultRestTemplate;
        this.tokenService = tokenService;
    }

    public void procesarDeuda(DeudaRequest request) {
        // Obtener el token de acceso
        String token = tokenService.getAccessToken();

        // Crear los encabezados para la consulta a Experian
        HttpHeaders experianHeaders = new HttpHeaders();
        experianHeaders.set("Content-Type", "application/json");
        experianHeaders.set("Authorization", "Bearer " + token);

        // Crear la entidad de la solicitud
        HttpEntity<DeudaRequest> requestEntity = new HttpEntity<>(request, experianHeaders);

        try {
            // Consultar Experian utilizando el RestTemplate con proxy
            String responseString = proxyRestTemplate.postForObject(deudaServiceUrl, requestEntity, String.class);
            System.out.println("Respuesta de Experian: " + responseString);

            // Configurar ObjectMapper para ignorar campos desconocidos
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            // Mapear la respuesta al objeto DeudaResponse
            DeudaResponse deudaResponse = objectMapper.readValue(responseString, DeudaResponse.class);

            // Validar si la respuesta es válida antes de enviar al destino
            if (deudaResponse == null || deudaResponse.getData() == null) {
                throw new RuntimeException("La respuesta de Experian no es válida o está incompleta.");
            }

            if (deudaResponse.getData().getCodigoRetorno() != 10000) {
                throw new RuntimeException(
                        "Código de retorno inválido de Experian: " + deudaResponse.getData().getCodigoRetorno());
            }

            if ("S".equals(deudaResponse.getData().getResumen().getExisteDetalle())
                    && (deudaResponse.getData().getDetalle() == null
                            || deudaResponse.getData().getDetalle().isEmpty())) {
                throw new RuntimeException("La respuesta indica que hay detalles, pero no se encontraron.");
            }

            // Construir el request para el servicio de destino
            DestinoRequest destinoRequest = new DestinoRequest();
            destinoRequest.setSzData(responseString); // JSON de la respuesta original
            destinoRequest.setRutCliente(request.getRut());
            destinoRequest.setCodAccion("A");
            destinoRequest.setCodCon("IR07");
            destinoRequest.setIntCant(0);
            destinoRequest.setSzModo("E");

            // Crear los encabezados para el servicio de destino
            HttpHeaders destinoHeaders = new HttpHeaders();
            destinoHeaders.set("Content-Type", "application/json");

            HttpEntity<DestinoRequest> destinoEntity = new HttpEntity<>(destinoRequest, destinoHeaders);

            // Enviar la solicitud al servicio de destino utilizando el RestTemplate sin
            // proxy
            ResponseEntity<String> destinoResponse = defaultRestTemplate.postForEntity(destinoServiceUrl, destinoEntity,
                    String.class);
            System.out.println("Respuesta del servicio de destino: " + destinoResponse.getBody());
        } catch (Exception e) {
            throw new RuntimeException("Error al procesar la deuda: " + e.getMessage(), e);
        }
    }
}
