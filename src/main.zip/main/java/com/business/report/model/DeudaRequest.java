package com.business.report.model;

import lombok.Data;

@Data
public class DeudaRequest {
    private String rut;
}
