package com.business.report.model;

import lombok.Data;

@Data
public class ConsolidadoMorosidadRequest {

    private String rut;

}
