package com.business.report.model;

import lombok.Data;

@Data
public class ExperianRequest {
    private String rut;
    private String serie;
}
